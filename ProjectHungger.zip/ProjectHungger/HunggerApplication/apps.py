from django.apps import AppConfig


class HunggerapplicationConfig(AppConfig):
    name = 'HunggerApplication'
