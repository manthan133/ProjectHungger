function os() {
        document.getElementById('signup').style.display='block';
        document.getElementById('main').style.opacity='0.25';
}
function cs() {
        document.getElementById('signup').style.display='none';
        document.getElementById('main').style.opacity='1.0';
}
function ol() {
        document.getElementById('login').style.display='block';
        document.getElementById('main').style.opacity='0.25';
}
function cl() {
        document.getElementById('login').style.display='none';
        document.getElementById('main').style.opacity='1.0';
}